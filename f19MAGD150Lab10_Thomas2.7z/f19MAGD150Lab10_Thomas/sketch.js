//variables

//I should note that I did this inside a local server on chrome. This will not work outside of that
let cam;
let button, phrase, input;

var chart;
//preload this
function preload(){
chart = loadTable('SmashNewcomers.csv', 'csv'); //SmashNewcomers.csv is in the file


}
//setup function
function setup() {
  createCanvas(400,400,WEBGL); //3D functionality
  //Video capturing functons
  cam =  createCapture(VIDEO);
  cam.size(100,100);
//This will print the amount of rows and columns to the console
print(chart.getRowCount());
print(chart.getColumnCount());
print(chart.getColumn("name"));
//more stuff
for (let r = 0; r < chart.getRowCount();r++)
{
	for (let c = 0;c<chart.getColumnCount();c++)
	{
		print(chart.getString(r,c));
	}
}
//button functionality
button = createButton('PRESS IT!');
button.position(300,400);
button.mousePressed(buttonPress);

phrase = createElement('h2', 'Press Here!')
phrase.position(180,380);

textAlign(CENTER);
textSize(20);
}

function draw() {
	//our shapes we will be using is in teh draw function
  background(230,100,70);
  push();
  noStroke();
  rotateY(frameCount * .01);
  texture(cam);
  sphere(30);
  pop();

  push();
  noStroke();
  translate(-100,-100,20);
  rotateX(frameCount *.01);
  rotateZ(frameCount * .01);
  specularMaterial(150);
  directionalLight(1000,80,200,1,1,-1);
  box(50);
  pop();

  push();
  noStroke();
  translate(100,100,20);
  rotateZ(180);
  rotateY(180);
  rotateY(frameCount * .02);
  ambientMaterial(100,80,120);
  ambientLight(200,50,50);
  cone(70);
pop();
//the camera is up to the user
camera(0,mouseY,mouseX,0,0,0,0,1,0);
if (mouseIsPressed)
{
	camera(mouseX,0,mouseY,0,0,0,0,1,0);
}

}
//This gives out info about the console if this is pressed.
function buttonPress(){
	print('This here on the console is the amount of Newcomers added to each Smash game as of November 2019');
}