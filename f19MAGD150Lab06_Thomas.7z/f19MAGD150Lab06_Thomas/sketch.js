//score variables
var a=0;
var b=0;
//ball variables
var ballX,ballY;
var ballspeed;
var ballspeed;
//bumper variables
var bumpY;
var bumpY2;
var bumpSpeed1;
var bumpSpeed2;
var bumpX;
var bumpX2;

function setup() {
	//our values for the game
  createCanvas(500,500);
  ballX= width/2;
  ballY = height/2;
  ballspeed=5;
  ballspeedY=6;
  bumpSpeed=9;
  bumpSpeed2=9;
  bumpY=50;
  bumpY2=400;
  bumpX=100;
  bumpX2=400;
}
//the game
function draw() {
  background(0);
  score();
  ball();
  Bumpers();
  collisioncheck();
  textSize(30);
  fill(255);
  rotate(PI/3);
  text("PONG",125,-180);
  

}
//this displays the score of the game
function score()
{
	push();
	fill('#990000');
	textSize(30);
	translate(50,50);
	text(+a,0,0);
	scale(.5);
	pop();
	push();
	fill("#000099");
	textSize(30);
	translate(425,50);
	text(+b,0,0);
	pop();
}
function ball() //This function will allow the ball to move
{
	push();
	ellipse(ballX,ballY,20,20);
	ballX += ballspeed;
	ballY += ballspeedY;
	if(ballX<=0)
	{
	b = b+1;	
	ballspeed*=-1;
	ballX=250;
	ballY=250;
	}
	if(ballX>width)
	{
	a = a+1;
	ballspeed*=-1;
	ballX=250;
	ballY=250;
	}
	if(ballY-15<=0||ballY+15>height)
	{
		ballspeedY*=-1;
	}
	redraw();
	pop();
}
//this sets up the bumpers for the game, which move up and down
function Bumpers()
{
	push();
	rectMode(CENTER);
	fill('#990000');
	rect(bumpX,bumpY,20,150);
	fill('#000099');
	rect(bumpX2,bumpY2,20,150);
	bumpY+=bumpSpeed;
	bumpY2+=bumpSpeed2;
	if(bumpY<=0||bumpY+55>=height)
	{
		bumpSpeed*=-1;
	}
	if(bumpY2<=0||bumpY2+55>=height)
	{
		bumpSpeed2*=-1;
	}
	pop();
	push();
	fill('#000099');
	rect(0,-3,1000,10);
	scale(5);
	rect(-1,-1,1,1);
	pop();
	push();
	fill('#990000');
	rect(0,490,1000,10);
	pop();
}
//checks if the ball collides with the bumper
function collisioncheck()
{
	if (dist(ballX,ballY,bumpX,bumpY)<40){
		fill("#990000");
		ballspeed*=-1;
		ballspeedY *=-1;
	}
	if (dist(ballX,ballY,bumpX2,bumpY2)<40){
		fill("#000099");
		ballspeed*=-1;
		ballspeedY*=-1;
	}
	}
