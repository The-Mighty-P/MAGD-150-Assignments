function setup() {
	createCanvas(450,400);
  // put setup code here
}

function draw(){
background(0);
stroke(255);
strokeWeight(50);
fill(200);
point(25,30);
strokeWeight(5);
point(105,90);
point(180,20);
point(225,55);
point(368,105);
point(429,66);
point(99,12);

stroke(255);
strokeWeight(40);
fill(255);
line(0,400,450,400);
strokeWeight(5);
line(300,300,300,380);
line(100,150,100,200);
line(150,105,150,180);
line(225,105,225,180);
line(360,390,360,260);

stroke(255);
strokeWeight(10);
fill(255);
rect(0,380,50,90);
rectMode(CORNERS);
noFill();

rect(5,290,5,5);
fill(255);
rect(70,380,100,200);
rect(250,390,120,150);

fill(255);
ellipse(300,50,200,15);
ellipse(50,50,100,20);
ellipse(308,298,15,3);
ellipse(360,260,10,5);
ellipse(360,340,70,22);
ellipse(360,317,60,20);
ellipse(360,293,50,18);
ellipse(360,273,30,10);



strokeWeight(3);
point(25,30);
}