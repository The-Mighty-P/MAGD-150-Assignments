let rectX = 0;
let fr = 30;
let clr;
//setup
function setup() {
 createCanvas(500,550);
 background(0);
 textSize(30);
 fill(255);
 colorMode(HSB,100,100,100,360);
 stroke(20,20,20,360);
fill(15,60,90,360);
  ellipse(250,250,250,250);
  line(250,125,250,375);
  line(125,250,375,250);
  frameRate(fr);
  clr = color(230,120,0);
}
//draw
function draw() {
col = map(mouseX,0,500,0,300);
fill(col);
text('Pick a number 1-5',135,35);
rectX = rectX + 2 * (deltaTime / 20);

	if (mouseIsPressed)
{
	fill(col);
	textSize(30);
text("Looks good.",135,80);
}
var x = 10
while(x <= width)
{
	stroke('#000099');
	fill(col);
	ellipse(x,550,15,15);
	x = x+1;

}
if (rectX>=width)
{
	if (fr === 30){
		clr=color(0,230,120);
		fr = 10;
		frameRate(fr);
	}
	else{
		clr = color(230,0,120);
		fr = 20;
		frameRate(fr);
	}
	rectX = 0;

}
fill(clr);
rect(rectX,40,10,10);
}
//keypress
function keyPressed()
{
	noStroke();
if (key == '1')
{
	fill('#990000');
	ellipse(200,295,35,35);
	ellipse(175,200,35,35);
	ellipse(210,150,35,35);
	ellipse(315,335,35,35);
	ellipse(310,205,35,35);
	ellipse(290,275,35,35);
	ellipse(200,250,35,35);
	textSize(30);
	text('PEPPERONI',250,480);
}
else if (key == '2')
{
	fill('#990099');
	stroke('#998085');
	strokeWeight(10);
point(150,300);
point(200,280);
point(175,210);
point(290,245);
point(270,165);
point(300,300);
strokeWeight(1);
noStroke();
fill('#990099');
text('SAUSAGE',100,500);
textSize(30);
}
else if (key == '3')
{
noFill();
strokeWeight(5);
stroke(255);
arc(150,250,7,7,0,HALF_PI);
arc(350,250,15,15,0,QUARTER_PI);
arc(210,180,8,8,0,PI);
arc(180,165,7,7,QUARTER_PI,PI);
arc(165,310,9,9,0,TWO_PI);
arc(310,280,5,5,0,HALF_PI);
strokeWeight(1);
fill(255);
text('ONIONS',50,470);
textSize(30);
}
else if (key == '4')
{
strokeWeight(5);
stroke(0);
noFill();
ellipse(230,230,10,10);
ellipse(270,270,10,10);
ellipse(270,230,10,10);
ellipse(230,270,10,10);
stroke(255);
strokeWeight(1);
text('OLIVES',200,450);
textSize(30);
}
else if (key == '5')
{
fill('#009900');
stroke('#009900');
triangle(240,180,232,192,250,205);
triangle(300,280,285,285,310,270);
triangle(210,350,230,360,220,340);	
triangle(320,160,300,145,310,155);
textSize(30);
text('PEPPERS',300,500);
}
else
{
	fill(255);
	textSize(30);
	text('Invalid, 1-5',250,530);
}
}