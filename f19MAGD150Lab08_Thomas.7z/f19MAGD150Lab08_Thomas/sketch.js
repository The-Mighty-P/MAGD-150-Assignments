//note, this does not work in Chrome, so I used Edge instead.
var berylium;
var blackout;
var blackSun;
var pdf;

//our preload fucntion allows me to call in the texts and fonts in the folder
function preload(){
  berylium = loadFont("BERYLIUM.TTF");
  blackout = loadFont("BLACKOUT-MIDNIGHT.TTF");
  blackSun = loadStrings("BlackSun.txt");
}

function setup() {
	//setup
  createCanvas(500,500);
  background(0);
  textSize(20);
  textFont(blackout);
  pdf= createPDF();
  pdf.beginRecord();
}

function draw() {
  //vectors
  let v1 = createVector(250,250);
  let v2= createVector(250,250);
  // our vector functions. One scales with the mouse, the other can't scale as it is normalized. 
  var cl = createVector(mouseX,mouseY);
  let c = cl.mag();
  var cl2 = createVector(mouseX,mouseX);
  let c2 = cl2.normalize();

//this text is normalized, so it will not scale with the mouse movement
push();
  textAlign(CENTER,BOTTOM);
  stroke(255);
  textSize(20);
  fill(c2,0,0);
  textFont(berylium);
  text("Are you scared of the dark?", 250, 500);
pop();
//the poster will get brighter the further away from 0,0 the mouse gets
push();
 fill(c,0,0);
 rectMode(CENTER);
 rect(v1.x,v1.y,350,400);
 pop();
push();
 fill(0);
 stroke(255);
 arc(v2.x,v2.y,150,150,0,TWO_PI);
pop();

//our text for our poster
push();
textAlign(CENTER);
text("IT'S HIGH NOON...", 250,100);
textFont(berylium);
text("PCT PRODUCTIONS PRESENTS...", 250,350);
pop();
push();
textAlign(CENTER);
textFont(blackout);
textSize(45);
text("THE BLACK SUN",250,400);
pop();

push();
//our interaction function. Displays the string from BlackSun.txt
if (mouseIsPressed)
{
  textAlign(CENTER);
  background(0);
  fill(255);
  textSize(90);
  textFont(blackout);
  text(blackSun,250,250);
}
//this is so LIGHTS OUT does not appear behind the sketch.
else{
rectMode(CENTER);
fill(0);
rect(20,0,120,9000);
rect(500,0,150,9000);
}
pop();
}
function keyPressed()
{
	pdf.save();
	//save it as a pdf
}